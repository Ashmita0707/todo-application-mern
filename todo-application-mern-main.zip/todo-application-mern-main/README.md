# To-Do Application (React + Node.js + MongoDB)

This is a full-stack To-Do application developed using React for frontend,
Node.js and Express for backend, and MongoDB for database.
Data is exchanged using JSON format.
